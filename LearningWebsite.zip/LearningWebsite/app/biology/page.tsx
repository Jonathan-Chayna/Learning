import { ChapterCard } from '@/components/chapter-card'
import { SearchBar } from '@/components/search-bar'

const chapters = [
  { id: 1, title: 'Cell Biology', completed: true },
  { id: 2, title: 'Genetics', completed: false },
  { id: 3, title: 'Ecology', completed: false },
  { id: 4, title: 'Evolution', completed: false },
]

export default function BiologyPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Biology</h1>
      <SearchBar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {chapters.map((chapter) => (
          <ChapterCard key={chapter.id} chapter={chapter} subjectId="biology" />
        ))}
      </div>
    </div>
  )
}

