import { ChapterCard } from '@/components/chapter-card'
import { SearchBar } from '@/components/search-bar'

const chapters = [
  { id: 1, title: 'Atomic Structure', completed: true },
  { id: 2, title: 'Chemical Bonding', completed: false },
  { id: 3, title: 'Organic Chemistry', completed: false },
  { id: 4, title: 'Thermochemistry', completed: false },
]

export default function ChemistryPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Chemistry</h1>
      <SearchBar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {chapters.map((chapter) => (
          <ChapterCard key={chapter.id} chapter={chapter} subjectId="chemistry" />
        ))}
      </div>
    </div>
  )
}

