"use client"

import { useState } from 'react'
import { PhotoUpload } from '@/components/photo-upload'
import { AIProcessing } from '@/components/ai-processing'
import { NoteSection } from '@/components/note-section'
import { Button } from '@/components/ui/button'

// This would typically come from a database or API
const chaptersData = {
  '1': {
    '1': { title: 'Algebra', content: 'Algebra is a branch of mathematics...' },
    '2': { title: 'Geometry', content: 'Geometry is a branch of mathematics...' },
    '3': { title: 'Trigonometry', content: 'Trigonometry is a branch of mathematics...' },
  },
  '2': {
    '1': { title: 'Mechanics', content: 'Mechanics is a branch of physics...' },
    '2': { title: 'Thermodynamics', content: 'Thermodynamics is a branch of physics...' },
    '3': { title: 'Electromagnetism', content: 'Electromagnetism is a branch of physics...' },
  },
  '3': {
    '1': { title: 'Atomic Structure', content: 'Atomic structure refers to...' },
    '2': { title: 'Chemical Bonding', content: 'Chemical bonding is...' },
    '3': { title: 'Organic Chemistry', content: 'Organic chemistry is the study of...' },
  },
  '4': {
    '1': { title: 'Cell Biology', content: 'Cell biology is the study of...' },
    '2': { title: 'Genetics', content: 'Genetics is a branch of biology...' },
    '3': { title: 'Ecology', content: 'Ecology is the study of...' },
  },
}

export default function ChapterPage({ params }: { params: { subjectId: string, chapterId: string } }) {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [extractedText, setExtractedText] = useState<string | null>(null)
  const [aiSummary, setAiSummary] = useState<string | null>(null)
  const [aiExplanation, setAiExplanation] = useState<string | null>(null)

  const chapter = chaptersData[params.subjectId as keyof typeof chaptersData]?.[params.chapterId as keyof (typeof chaptersData)[keyof typeof chaptersData]]

  if (!chapter) {
    return <div>Chapter not found</div>
  }

  const handleImageUpload = (imageUrl: string) => {
    setUploadedImage(imageUrl)
    // Trigger AI processing here
  }

  const handleAIProcessing = (text: string, summary: string, explanation: string) => {
    setExtractedText(text)
    setAiSummary(summary)
    setAiExplanation(explanation)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">{chapter.title}</h1>
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Chapter Content</h2>
        <p>{chapter.content}</p>
      </div>
      <PhotoUpload onUpload={handleImageUpload} />
      {uploadedImage && (
        <AIProcessing
          imageUrl={uploadedImage}
          onProcessingComplete={handleAIProcessing}
        />
      )}
      {aiSummary && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Summary</h2>
          <p>{aiSummary}</p>
        </div>
      )}
      {aiExplanation && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Detailed Explanation</h2>
          <p>{aiExplanation}</p>
        </div>
      )}
      <NoteSection />
      <div className="mt-8">
        <Button>Mark as Completed</Button>
      </div>
    </div>
  )
}

