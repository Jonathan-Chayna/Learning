import { ChapterCard } from '@/components/chapter-card'
import { SearchBar } from '@/components/search-bar'

// This would typically come from a database or API
const subjectsData = {
  1: { name: 'Mathematics', chapters: [
    { id: 1, title: 'Algebra', completed: true },
    { id: 2, title: 'Geometry', completed: false },
    { id: 3, title: 'Trigonometry', completed: false },
  ]},
  2: { name: 'Physics', chapters: [
    { id: 1, title: 'Mechanics', completed: true },
    { id: 2, title: 'Thermodynamics', completed: false },
    { id: 3, title: 'Electromagnetism', completed: false },
  ]},
  3: { name: 'Chemistry', chapters: [
    { id: 1, title: 'Atomic Structure', completed: true },
    { id: 2, title: 'Chemical Bonding', completed: false },
    { id: 3, title: 'Organic Chemistry', completed: false },
  ]},
  4: { name: 'Biology', chapters: [
    { id: 1, title: 'Cell Biology', completed: true },
    { id: 2, title: 'Genetics', completed: false },
    { id: 3, title: 'Ecology', completed: false },
  ]},
}

export default function SubjectPage({ params }: { params: { id: string } }) {
  const subject = subjectsData[params.id as keyof typeof subjectsData]

  if (!subject) {
    return <div>Subject not found</div>
  }

  return (
    <>
      <h1 className="text-4xl font-bold mb-8">{subject.name}</h1>
      <SearchBar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {subject.chapters.map((chapter) => (
          <ChapterCard key={chapter.id} chapter={chapter} subjectId={params.id} />
        ))}
      </div>
    </>
  )
}

