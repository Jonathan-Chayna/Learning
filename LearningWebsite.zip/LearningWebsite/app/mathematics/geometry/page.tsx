import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function GeometryPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Geometry</h1>
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Chapter Overview</CardTitle>
          <CardDescription>Exploring shapes and spaces</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Geometry is a branch of mathematics concerned with questions of shape, size, relative position of figures, and the properties of space.</p>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Key Concepts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Points, Lines, and Angles</li>
              <li>Polygons and Circles</li>
              <li>Area and Volume</li>
              <li>Coordinate Geometry</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Learning Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Interactive Diagrams</li>
              <li>Video Tutorials</li>
              <li>Problem Sets</li>
              <li>Geometric Proofs</li>
            </ul>
          </CardContent>
        </Card>
      </div>
      <div className="mt-8 flex justify-between">
        <Button asChild>
          <Link href="/mathematics">Back to Mathematics</Link>
        </Button>
        <Button>Start Learning</Button>
      </div>
    </div>
  )
}

