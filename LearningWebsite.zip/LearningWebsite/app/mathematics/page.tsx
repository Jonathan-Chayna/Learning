import { ChapterCard } from '@/components/chapter-card'
import { SearchBar } from '@/components/search-bar'

const chapters = [
  { id: 1, title: 'Algebra', completed: true },
  { id: 2, title: 'Geometry', completed: false },
  { id: 3, title: 'Trigonometry', completed: false },
  { id: 4, title: 'Calculus', completed: false },
]

export default function MathematicsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Mathematics</h1>
      <SearchBar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {chapters.map((chapter) => (
          <ChapterCard key={chapter.id} chapter={chapter} subjectId="mathematics" />
        ))}
      </div>
    </div>
  )
}

