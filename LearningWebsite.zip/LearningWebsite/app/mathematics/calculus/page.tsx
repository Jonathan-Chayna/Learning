import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function CalculusPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Calculus</h1>
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Chapter Overview</CardTitle>
          <CardDescription>The study of continuous change</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Calculus is the mathematical study of continuous change. It provides a framework for modeling systems in which there is a rate of change between variables, and provides methods for calculating these rates and accumulating quantities over time.</p>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Key Concepts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Limits and Continuity</li>
              <li>Differentiation</li>
              <li>Integration</li>
              <li>Applications of Calculus</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Learning Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Interactive Graphs</li>
              <li>Video Lectures</li>
              <li>Problem Sets</li>
              <li>Real-world Examples</li>
            </ul>
          </CardContent>
        </Card>
      </div>
      <div className="mt-8 flex justify-between">
        <Button asChild>
          <Link href="/mathematics">Back to Mathematics</Link>
        </Button>
        <Button>Start Learning</Button>
      </div>
    </div>
  )
}

