import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function AlgebraPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Algebra</h1>
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Chapter Overview</CardTitle>
          <CardDescription>An introduction to algebraic concepts</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Algebra is a branch of mathematics dealing with symbols and the rules for manipulating those symbols. It is a unifying thread of almost all of mathematics.</p>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Key Concepts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Variables and Constants</li>
              <li>Equations and Inequalities</li>
              <li>Functions and Graphs</li>
              <li>Polynomials</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Learning Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Video Lectures</li>
              <li>Interactive Exercises</li>
              <li>Practice Problems</li>
              <li>Quizzes</li>
            </ul>
          </CardContent>
        </Card>
      </div>
      <div className="mt-8 flex justify-between">
        <Button asChild>
          <Link href="/mathematics">Back to Mathematics</Link>
        </Button>
        <Button>Start Learning</Button>
      </div>
    </div>
  )
}

