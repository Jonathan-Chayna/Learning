import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function TrigonometryPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Trigonometry</h1>
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Chapter Overview</CardTitle>
          <CardDescription>The study of relationships between side lengths and angles of triangles</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Trigonometry is a branch of mathematics that studies relationships between side lengths and angles of triangles. It has applications in both pure mathematics and in applied mathematics, where it is essential in many branches of science and technology.</p>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Key Concepts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Trigonometric Functions</li>
              <li>Radians and Degrees</li>
              <li>Trigonometric Identities</li>
              <li>Solving Triangles</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Learning Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5">
              <li>Interactive Unit Circle</li>
              <li>Video Lessons</li>
              <li>Practice Exercises</li>
              <li>Real-world Applications</li>
            </ul>
          </CardContent>
        </Card>
      </div>
      <div className="mt-8 flex justify-between">
        <Button asChild>
          <Link href="/mathematics">Back to Mathematics</Link>
        </Button>
        <Button>Start Learning</Button>
      </div>
    </div>
  )
}

