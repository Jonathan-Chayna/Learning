import { SubjectCard } from '@/components/subject-card'
import { SearchBar } from '@/components/search-bar'

const subjects = [
  { id: 1, name: 'Mathematics', chapters: 4 },
  { id: 2, name: 'Physics', chapters: 4 },
  { id: 3, name: 'Chemistry', chapters: 4 },
  { id: 4, name: 'Biology', chapters: 4 },
]

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">My Learning Dashboard</h1>
      <SearchBar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {subjects.map((subject) => (
          <SubjectCard key={subject.id} subject={subject} />
        ))}
      </div>
    </div>
  )
}

