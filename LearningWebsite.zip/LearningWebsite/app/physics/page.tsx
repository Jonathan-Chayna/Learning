import { ChapterCard } from '@/components/chapter-card'
import { SearchBar } from '@/components/search-bar'

const chapters = [
  { id: 1, title: 'Mechanics', completed: true },
  { id: 2, title: 'Thermodynamics', completed: false },
  { id: 3, title: 'Electromagnetism', completed: false },
  { id: 4, title: 'Quantum Physics', completed: false },
]

export default function PhysicsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Physics</h1>
      <SearchBar />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {chapters.map((chapter) => (
          <ChapterCard key={chapter.id} chapter={chapter} subjectId="physics" />
        ))}
      </div>
    </div>
  )
}

