import Link from 'next/link'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'

interface SubjectCardProps {
  subject: {
    id: number
    name: string
    chapters: number
  }
}

export function SubjectCard({ subject }: SubjectCardProps) {
  return (
    <Link href={`/${subject.name.toLowerCase()}`} className="block">
      <Card className="hover:shadow-lg transition-shadow duration-300 cursor-pointer">
        <CardHeader>
          <CardTitle>{subject.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <p>{subject.chapters} chapters</p>
        </CardContent>
      </Card>
    </Link>
  )
}

