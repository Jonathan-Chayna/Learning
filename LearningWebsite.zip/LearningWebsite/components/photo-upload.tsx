"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface PhotoUploadProps {
  onUpload: (imageUrl: string) => void
}

export function PhotoUpload({ onUpload }: PhotoUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
    }
  }

  const handleUpload = () => {
    if (selectedFile) {
      // In a real application, you would upload the file to a server here
      // For this example, we'll just create a local URL
      const imageUrl = URL.createObjectURL(selectedFile)
      onUpload(imageUrl)
    }
  }

  return (
    <div className="flex items-center space-x-4">
      <Input type="file" accept="image/*" onChange={handleFileChange} />
      <Button onClick={handleUpload} disabled={!selectedFile}>
        Upload Photo
      </Button>
    </div>
  )
}

