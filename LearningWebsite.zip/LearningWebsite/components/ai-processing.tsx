"use client"

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'

interface AIProcessingProps {
  imageUrl: string
  onProcessingComplete: (text: string, summary: string, explanation: string) => void
}

export function AIProcessing({ imageUrl, onProcessingComplete }: AIProcessingProps) {
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    // In a real application, you would call an API to process the image here
    // For this example, we'll just simulate processing with a timeout
    setIsProcessing(true)
    const timer = setTimeout(() => {
      const mockText = "This is the extracted text from the image."
      const mockSummary = "This is a summary of the extracted text."
      const mockExplanation = "This is a detailed explanation of the content."
      onProcessingComplete(mockText, mockSummary, mockExplanation)
      setIsProcessing(false)
    }, 3000)

    return () => clearTimeout(timer)
  }, [imageUrl, onProcessingComplete])

  return (
    <div className="mt-4">
      {isProcessing ? (
        <p>Processing image...</p>
      ) : (
        <Button onClick={() => setIsProcessing(true)}>Reprocess Image</Button>
      )}
    </div>
  )
}

