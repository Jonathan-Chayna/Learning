import Link from 'next/link'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

interface ChapterCardProps {
  chapter: {
    id: number
    title: string
    completed: boolean
  }
  subjectId: string
}

export function ChapterCard({ chapter, subjectId }: ChapterCardProps) {
  const chapterSlug = chapter.title.toLowerCase().replace(' ', '-')
  return (
    <Link href={`/${subjectId}/${chapterSlug}`} className="block">
      <Card className="hover:shadow-lg transition-shadow duration-300 cursor-pointer">
        <CardHeader>
          <CardTitle>{chapter.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <Badge variant={chapter.completed ? "success" : "secondary"}>
            {chapter.completed ? "Completed" : "To Review"}
          </Badge>
        </CardContent>
      </Card>
    </Link>
  )
}

