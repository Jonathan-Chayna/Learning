"use client"

import { useState } from 'react'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'

export function NoteSection() {
  const [note, setNote] = useState('')

  const handleNoteChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNote(e.target.value)
  }

  const handleSaveNote = () => {
    // In a real application, you would save the note to a database here
    console.log('Saving note:', note)
  }

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-4">Personal Notes</h2>
      <Textarea
        value={note}
        onChange={handleNoteChange}
        placeholder="Write your personal notes here..."
        className="mb-4"
      />
      <Button onClick={handleSaveNote}>Save Note</Button>
    </div>
  )
}

